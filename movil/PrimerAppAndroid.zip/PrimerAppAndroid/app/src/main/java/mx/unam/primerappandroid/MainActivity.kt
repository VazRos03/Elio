package mx.unam.primerappandroid

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {

    // Constante para la clave del dato (el nombre) que pasaremos
    companion object {
        const val EXTRA_NAME = "com.example.miprimeraapp.NAME"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Vincula esta Activity con el archivo de layout activity_main.xml
        setContentView(R.layout.activity_main)

        // 1. Obtener las referencias de los componentes de la interfaz
        val nameInput = findViewById<EditText>(R.id.editTextName)
        val greetButton = findViewById<Button>(R.id.buttonGreet)

        // 2. Configurar el listener de click para el botón SALUDAR
        greetButton.setOnClickListener {
            // 3. Obtener el texto ingresado por el usuario
            val name = nameInput.text.toString().trim()

            // 4. Crear un Intent para iniciar la SaludoActivity
            val intent = Intent(this, SaludoActivity::class.java).apply {
                // 5. Agregar el nombre como un 'extra' para pasarlo a la otra Activity
                putExtra(EXTRA_NAME, name)
            }

            // 6. Iniciar la nueva Activity
            startActivity(intent)
        }
    }
}