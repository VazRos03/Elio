package mx.unam.primerappandroid

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SaludoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Vincula esta Activity con el archivo de layout activity_saludo.xml
        setContentView(R.layout.activity_saludo)

        // 1. Obtener la referencia del TextView
        val saludoTextView = findViewById<TextView>(R.id.textViewSaludo)

        // 2. Obtener el Intent que inició esta Activity
        val intent = intent

        // 3. Extraer el nombre que se pasó desde MainActivity
        // Usamos la misma constante de clave definida en MainActivity
        val name = intent.getStringExtra(MainActivity.EXTRA_NAME)

        // 4. Construir y mostrar el mensaje de saludo
        if (name.isNullOrEmpty()) {
            saludoTextView.text = "¡Hola, invitado anónimo!"
        } else {
            saludoTextView.text = "¡Hola, $name!\n¡Bienvenido a tu App!"
        }
    }
}