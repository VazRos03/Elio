package mx.unam.primerappandroid

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
/*Luis Arturo Vazquez Rosales
* Tarea 2
* Agregar dos Campos mas en el saludo
* En nuestro caso agregamos para preguntar la edad y la ocupacion del usuario en
* la aplicacion*/

class MainActivity : AppCompatActivity() {

    // Constantes para las claves de los datos (EXTRAS) que pasaremos
    companion object {
        const val EXTRA_NAME = "mx.unam.primerappandroid.NAME"
        // Nuevas constantes para los datos adicionales
        const val EXTRA_AGE = "mx.unam.primerappandroid.AGE"
        const val EXTRA_OCCUPATION = "mx.unam.primerappandroid.OCCUPATION"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 1. Obtener referencias de los 3 campos de texto y el botón
        val nameInput = findViewById<EditText>(R.id.editTextName)
        val ageInput = findViewById<EditText>(R.id.editTextAge) // Nuevo
        val occupationInput = findViewById<EditText>(R.id.editTextOccupation) // Nuevo
        val greetButton = findViewById<Button>(R.id.buttonGreet)

        greetButton.setOnClickListener {
            // 2. Obtener los 3 valores ingresados por el usuario
            val name = nameInput.text.toString().trim()
            val age = ageInput.text.toString().trim()
            val occupation = occupationInput.text.toString().trim()

            // 3. Crear el Intent y pasar los 3 datos como 'extras'
            val intent = Intent(this, SaludoActivity::class.java).apply {
                putExtra(EXTRA_NAME, name)
                putExtra(EXTRA_AGE, age) // Nuevo dato enviado
                putExtra(EXTRA_OCCUPATION, occupation) // Nuevo dato enviado
            }

            // 4. Iniciar la nueva Activity
            startActivity(intent)
        }
    }
}