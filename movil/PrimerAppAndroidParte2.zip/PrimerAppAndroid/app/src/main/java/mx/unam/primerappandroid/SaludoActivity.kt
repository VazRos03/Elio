package mx.unam.primerappandroid

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SaludoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_saludo)

        // 1. Obtener las referencias de los 3 TextViews
        val saludoTextView = findViewById<TextView>(R.id.textViewSaludo)
        val ageTextView = findViewById<TextView>(R.id.textViewAge) // Nuevo
        val occupationTextView = findViewById<TextView>(R.id.textViewOccupation) // Nuevo

        // 2. Obtener los Intent Extras
        val name = intent.getStringExtra(MainActivity.EXTRA_NAME)
        val age = intent.getStringExtra(MainActivity.EXTRA_AGE) // Dato de edad
        val occupation = intent.getStringExtra(MainActivity.EXTRA_OCCUPATION) // Dato de ocupación

        // 3. Mostrar el mensaje de saludo principal (Nombre)
        if (name.isNullOrEmpty()) {
            saludoTextView.text = "¡Hola, usuario anónimo!"
        } else {
            saludoTextView.text = "¡Hola, $name!"
        }

        // 4. Mostrar la Edad (con manejo de campo vacío)
        if (age.isNullOrEmpty()) {
            ageTextView.text = "Edad no especificada."
        } else {
            ageTextView.text = "Tienes $age años."
        }

        // 5. Mostrar la Ocupación (con manejo de campo vacío)
        if (occupation.isNullOrEmpty()) {
            occupationTextView.text = "Ocupación: No capturada."
        } else {
            occupationTextView.text = "Tu ocupación es: $occupation."
        }
    }
}